
  # Travel Agent Interface Design

  This is a code bundle for Travel Agent Interface Design. The original project is available at https://www.figma.com/design/040bhwCjCZWEsc7eFviEgi/Travel-Agent-Interface-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  