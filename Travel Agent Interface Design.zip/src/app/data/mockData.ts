export interface Traveler {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar?: string;
}

export interface Expense {
  id: string;
  travelerId: string;
  amount: number;
  currency: string;
  category: 'flight' | 'hotel' | 'meals' | 'transportation' | 'entertainment' | 'other';
  vendor: string;
  date: string;
  description: string;
  receiptUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  linkedBookingId?: string; // Optional link to flight or hotel ID
  linkedBookingType?: 'flight' | 'hotel';
}

export interface Trip {
  id: string;
  title: string;
  destination: string;
  startDate: string;
  endDate: string;
  status: 'upcoming' | 'past' | 'in-progress';
  travelers: Traveler[];
  imageUrl: string;
  flights: Flight[];
  hotels: Hotel[];
  expenses: Expense[];
  budget: {
    total: number;
    spent: number;
  };
}

export interface Flight {
  id: string;
  airline: string;
  flightNumber: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  duration: string;
  class: string;
  price: number;
  status: string;
  travelers: string[]; // Array of traveler IDs
}

export interface Hotel {
  id: string;
  name: string;
  address: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  roomType: string;
  price: number;
  status: string;
  travelers: string[]; // Array of traveler IDs
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface AIAction {
  id: string;
  type: 'searching' | 'processing' | 'completed' | 'optimizing' | 'analyzing';
  action: string;
  description: string;
  timestamp: Date;
  progress?: number; // 0-100 for in-progress actions
  tripId?: string;
  metadata?: {
    itemsProcessed?: number;
    totalItems?: number;
    details?: string;
  };
}

export const mockAIActions: AIAction[] = [
  {
    id: 'a1',
    type: 'completed',
    action: 'Processed expense receipts',
    description: 'Automatically extracted details from 3 receipts and categorized expenses',
    timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
    tripId: '1',
    metadata: {
      itemsProcessed: 3,
      totalItems: 3,
    }
  },
  {
    id: 'a2',
    type: 'completed',
    action: 'Optimized flight itinerary',
    description: 'Found alternative flights saving $450 across all travelers',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
    tripId: '2',
  },
  {
    id: 'a3',
    type: 'completed',
    action: 'Monitored price changes',
    description: 'Detected hotel price drop for Park Hyatt Tokyo - saved $200',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    tripId: '1',
  },
  {
    id: 'a4',
    type: 'completed',
    action: 'Updated travel documents',
    description: 'Checked visa requirements for all travelers - no action needed',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
    tripId: '1',
  },
];

export const mockTrips: Trip[] = [
  {
    id: '1',
    title: 'Tokyo Business Summit',
    destination: 'Tokyo, Japan',
    startDate: '2026-03-15',
    endDate: '2026-03-22',
    status: 'upcoming',
    travelers: [
      {
        id: 't1',
        name: 'Sarah Chen',
        email: 'sarah.chen@company.com',
        role: 'VP of Operations',
      },
      {
        id: 't2',
        name: 'Michael Rodriguez',
        email: 'michael.r@company.com',
        role: 'Senior Engineer',
      },
      {
        id: 't3',
        name: 'Emily Watson',
        email: 'emily.w@company.com',
        role: 'Product Manager',
      },
    ],
    imageUrl: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800',
    budget: {
      total: 12500,
      spent: 9200
    },
    flights: [
      {
        id: 'f1',
        airline: 'Japan Airlines',
        flightNumber: 'JL5',
        from: 'San Francisco (SFO)',
        to: 'Tokyo Narita (NRT)',
        departure: '2026-03-15T11:00:00',
        arrival: '2026-03-16T14:30:00',
        duration: '11h 30m',
        class: 'Business',
        price: 3200,
        status: 'Confirmed',
        travelers: ['t1', 't2', 't3'],
      },
      {
        id: 'f2',
        airline: 'Japan Airlines',
        flightNumber: 'JL6',
        from: 'Tokyo Narita (NRT)',
        to: 'San Francisco (SFO)',
        departure: '2026-03-22T16:00:00',
        arrival: '2026-03-22T09:30:00',
        duration: '10h 30m',
        class: 'Business',
        price: 3200,
        status: 'Confirmed',
        travelers: ['t1', 't2', 't3'],
      }
    ],
    hotels: [
      {
        id: 'h1',
        name: 'Park Hyatt Tokyo',
        address: '3-7-1-2 Nishi Shinjuku, Shinjuku-ku, Tokyo',
        checkIn: '2026-03-16',
        checkOut: '2026-03-22',
        nights: 6,
        roomType: 'Deluxe Twin Room',
        price: 2800,
        status: 'Confirmed',
        travelers: ['t1', 't2', 't3'],
      }
    ],
    expenses: [
      {
        id: 'e1',
        travelerId: 't1',
        amount: 100,
        currency: 'USD',
        category: 'meals',
        vendor: 'Sushi Saito',
        date: '2026-03-16',
        description: 'Lunch with team',
        receiptUrl: 'https://example.com/receipts/e1.png',
        status: 'approved',
        linkedBookingId: 'h1',
        linkedBookingType: 'hotel'
      },
      {
        id: 'e2',
        travelerId: 't2',
        amount: 50,
        currency: 'USD',
        category: 'transportation',
        vendor: 'Tokyo Metro',
        date: '2026-03-17',
        description: 'Commute to meeting',
        receiptUrl: 'https://example.com/receipts/e2.png',
        status: 'pending'
      }
    ]
  },
  {
    id: '2',
    title: 'London Tech Conference',
    destination: 'London, UK',
    startDate: '2026-04-10',
    endDate: '2026-04-15',
    status: 'upcoming',
    travelers: [
      {
        id: 't4',
        name: 'David Park',
        email: 'david.p@company.com',
        role: 'CTO',
      },
      {
        id: 't5',
        name: 'Lisa Johnson',
        email: 'lisa.j@company.com',
        role: 'Lead Developer',
      },
      {
        id: 't6',
        name: 'James Wilson',
        email: 'james.w@company.com',
        role: 'UX Director',
      },
      {
        id: 't7',
        name: 'Anna Martinez',
        email: 'anna.m@company.com',
        role: 'Data Scientist',
      },
      {
        id: 't8',
        name: 'Tom Anderson',
        email: 'tom.a@company.com',
        role: 'DevOps Lead',
      },
    ],
    imageUrl: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800',
    budget: {
      total: 18000,
      spent: 14500
    },
    flights: [
      {
        id: 'f3',
        airline: 'British Airways',
        flightNumber: 'BA284',
        from: 'New York (JFK)',
        to: 'London Heathrow (LHR)',
        departure: '2026-04-10T20:30:00',
        arrival: '2026-04-11T08:15:00',
        duration: '6h 45m',
        class: 'Business',
        price: 2500,
        status: 'Confirmed',
        travelers: ['t4', 't5', 't6'],
      },
      {
        id: 'f4',
        airline: 'British Airways',
        flightNumber: 'BA178',
        from: 'Boston (BOS)',
        to: 'London Heathrow (LHR)',
        departure: '2026-04-10T22:00:00',
        arrival: '2026-04-11T10:30:00',
        duration: '6h 30m',
        class: 'Premium Economy',
        price: 1800,
        status: 'Confirmed',
        travelers: ['t7', 't8'],
      }
    ],
    hotels: [
      {
        id: 'h2',
        name: 'The Savoy',
        address: 'Strand, London WC2R 0EZ',
        checkIn: '2026-04-11',
        checkOut: '2026-04-15',
        nights: 4,
        roomType: 'Superior Room',
        price: 1800,
        status: 'Confirmed',
        travelers: ['t4', 't5'],
      },
      {
        id: 'h3',
        name: 'The Savoy',
        address: 'Strand, London WC2R 0EZ',
        checkIn: '2026-04-11',
        checkOut: '2026-04-15',
        nights: 4,
        roomType: 'Deluxe Room',
        price: 2200,
        status: 'Confirmed',
        travelers: ['t6', 't7', 't8'],
      }
    ],
    expenses: [
      {
        id: 'e3',
        travelerId: 't4',
        amount: 200,
        currency: 'USD',
        category: 'meals',
        vendor: 'The Savoy Restaurant',
        date: '2026-04-11',
        description: 'Dinner with team',
        receiptUrl: 'https://example.com/receipts/e3.png',
        status: 'approved',
        linkedBookingId: 'h2',
        linkedBookingType: 'hotel'
      },
      {
        id: 'e4',
        travelerId: 't5',
        amount: 150,
        currency: 'USD',
        category: 'transportation',
        vendor: 'London Underground',
        date: '2026-04-12',
        description: 'Commute to meeting',
        receiptUrl: 'https://example.com/receipts/e4.png',
        status: 'pending'
      }
    ]
  },
  {
    id: '3',
    title: 'Singapore Innovation Week',
    destination: 'Singapore',
    startDate: '2026-02-05',
    endDate: '2026-02-12',
    status: 'past',
    travelers: [
      {
        id: 't9',
        name: 'Rachel Green',
        email: 'rachel.g@company.com',
        role: 'Innovation Lead',
      },
      {
        id: 't10',
        name: 'Chris Taylor',
        email: 'chris.t@company.com',
        role: 'Strategy Director',
      },
    ],
    imageUrl: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=800',
    budget: {
      total: 9500,
      spent: 9500
    },
    flights: [
      {
        id: 'f5',
        airline: 'Singapore Airlines',
        flightNumber: 'SQ12',
        from: 'Los Angeles (LAX)',
        to: 'Singapore (SIN)',
        departure: '2026-02-05T00:30:00',
        arrival: '2026-02-06T07:45:00',
        duration: '17h 15m',
        class: 'Premium Economy',
        price: 1800,
        status: 'Completed',
        travelers: ['t9', 't10'],
      }
    ],
    hotels: [
      {
        id: 'h4',
        name: 'Marina Bay Sands',
        address: '10 Bayfront Avenue, Singapore 018956',
        checkIn: '2026-02-06',
        checkOut: '2026-02-12',
        nights: 6,
        roomType: 'Premier Room',
        price: 2400,
        status: 'Completed',
        travelers: ['t9', 't10'],
      }
    ],
    expenses: [
      {
        id: 'e5',
        travelerId: 't9',
        amount: 150,
        currency: 'USD',
        category: 'meals',
        vendor: 'Marina Bay Sands Restaurant',
        date: '2026-02-06',
        description: 'Lunch with team',
        receiptUrl: 'https://example.com/receipts/e5.png',
        status: 'approved',
        linkedBookingId: 'h4',
        linkedBookingType: 'hotel'
      },
      {
        id: 'e6',
        travelerId: 't10',
        amount: 100,
        currency: 'USD',
        category: 'transportation',
        vendor: 'Grab',
        date: '2026-02-07',
        description: 'Commute to meeting',
        receiptUrl: 'https://example.com/receipts/e6.png',
        status: 'pending'
      }
    ]
  }
];

export const initialChatMessages: ChatMessage[] = [
  {
    id: '1',
    role: 'assistant',
    content: 'Hello! I\'m your AI travel assistant. I can help you plan trips, make changes to existing bookings, answer questions about your itinerary, and provide travel recommendations. How can I assist you today?',
    timestamp: new Date(Date.now() - 1000 * 60 * 5)
  }
];