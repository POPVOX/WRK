import { Sparkles, CheckCircle2, Loader2 } from 'lucide-react';
import { AIAction } from '../data/mockData';

interface ActivityStreamProps {
  actions: AIAction[];
  limit?: number;
}

export function ActivityStream({ actions, limit }: ActivityStreamProps) {
  const displayActions = limit ? actions.slice(0, limit) : actions;

  const getRelativeTime = (date: Date): string => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  };

  const getActionIcon = (action: AIAction) => {
    switch (action.type) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'processing':
      case 'searching':
      case 'analyzing':
      case 'optimizing':
        return <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />;
      default:
        return <Sparkles className="w-4 h-4 text-blue-600" />;
    }
  };

  const getActionColor = (action: AIAction) => {
    switch (action.type) {
      case 'completed':
        return 'bg-green-50 border-green-200';
      case 'processing':
      case 'searching':
      case 'analyzing':
      case 'optimizing':
        return 'bg-blue-50 border-blue-200';
      default:
        return 'bg-zinc-50 border-zinc-200';
    }
  };

  if (displayActions.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-zinc-200 p-8 text-center">
        <Sparkles className="w-8 h-8 text-zinc-300 mx-auto mb-3" />
        <p className="text-zinc-600">No AI activity yet</p>
        <p className="text-sm text-zinc-500 mt-1">
          The AI agent will automatically work on optimizing your trips
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {displayActions.map((action, index) => (
        <div
          key={action.id}
          className={`relative rounded-lg border p-4 transition-all ${getActionColor(
            action
          )}`}
        >
          {/* Timeline connector */}
          {index < displayActions.length - 1 && (
            <div className="absolute left-[27px] top-[48px] w-px h-[calc(100%+12px)] bg-zinc-200" />
          )}

          <div className="flex items-start gap-3">
            <div className="p-2 bg-white rounded-lg border border-zinc-200 flex-shrink-0">
              {getActionIcon(action)}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <h4 className="font-medium text-zinc-900 text-sm">
                    {action.action}
                  </h4>
                  <p className="text-sm text-zinc-600 mt-1">
                    {action.description}
                  </p>

                  {action.metadata?.details && (
                    <p className="text-xs text-zinc-500 mt-2 bg-white/50 rounded px-2 py-1 inline-block">
                      {action.metadata.details}
                    </p>
                  )}

                  {action.progress !== undefined && action.type !== 'completed' && (
                    <div className="mt-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-zinc-600">Progress</span>
                        <span className="text-xs font-medium text-blue-700">
                          {action.progress}%
                        </span>
                      </div>
                      <div className="h-1.5 bg-white rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 transition-all duration-300"
                          style={{ width: `${action.progress}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="text-right flex-shrink-0">
                  <span className="text-xs text-zinc-500">
                    {getRelativeTime(action.timestamp)}
                  </span>
                  {action.type === 'completed' && (
                    <div className="mt-1">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                        <CheckCircle2 className="w-3 h-3" />
                        Done
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
