import { useParams, Link } from 'react-router';
import {
  ArrowLeft,
  Calendar,
  MapPin,
  Users,
  Plane,
  Hotel,
  Edit,
  DollarSign,
  Clock,
  Receipt,
  Sparkles,
} from 'lucide-react';
import { mockTrips, mockAIActions, Expense } from '../data/mockData';
import { useState } from 'react';
import { TripExpenses } from './TripExpenses';
import { ActivityStream } from './ActivityStream';

export function TripDetails() {
  const { tripId } = useParams();
  const trip = mockTrips.find((t) => t.id === tripId);
  const [activeTab, setActiveTab] = useState<'itinerary' | 'expenses' | 'activity'>('itinerary');

  if (!trip) {
    return (
      <div className="p-8">
        <div className="bg-white rounded-xl p-8 text-center">
          <p className="text-zinc-600">Trip not found</p>
          <Link to="/" className="text-blue-600 hover:text-blue-700 mt-4 inline-block">
            Return to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  const budgetPercentage = (trip.budget.spent / trip.budget.total) * 100;
  const tripAIActions = mockAIActions.filter(action => action.tripId === trip.id);

  const handleAddExpense = (expense: Expense) => {
    // In a real app, this would save to the backend
    console.log('New expense added:', expense);
  };

  return (
    <div className="p-8">
      {/* Back Button */}
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-zinc-600 hover:text-zinc-900 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Dashboard
      </Link>

      {/* Hero Section */}
      <div className="relative h-80 rounded-xl overflow-hidden mb-8">
        <img src={trip.imageUrl} alt={trip.destination} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <div className="absolute bottom-8 left-8 text-white">
          <h1 className="text-4xl font-semibold mb-2">{trip.title}</h1>
          <div className="flex items-center gap-2 text-lg">
            <MapPin className="w-5 h-5" />
            <span>{trip.destination}</span>
          </div>
        </div>
        <div className="absolute top-8 right-8">
          <button className="bg-white text-zinc-900 px-4 py-2 rounded-lg font-medium hover:bg-zinc-100 transition-colors flex items-center gap-2">
            <Edit className="w-4 h-4" />
            Edit Trip
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-zinc-200 mb-8">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('itinerary')}
            className={`pb-4 px-2 border-b-2 transition-colors ${
              activeTab === 'itinerary'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Plane className="w-4 h-4" />
              <span className="font-medium">Itinerary</span>
            </div>
          </button>
          <button
            onClick={() => setActiveTab('expenses')}
            className={`pb-4 px-2 border-b-2 transition-colors ${
              activeTab === 'expenses'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4" />
              <span className="font-medium">Expenses</span>
              {trip.expenses.filter(e => e.status === 'pending').length > 0 && (
                <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs font-medium">
                  {trip.expenses.filter(e => e.status === 'pending').length}
                </span>
              )}
            </div>
          </button>
          <button
            onClick={() => setActiveTab('activity')}
            className={`pb-4 px-2 border-b-2 transition-colors ${
              activeTab === 'activity'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-zinc-600 hover:text-zinc-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span className="font-medium">AI Activity</span>
              {tripAIActions.length > 0 && (
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                  {tripAIActions.length}
                </span>
              )}
            </div>
          </button>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'itinerary' ? (
        <ItineraryTab trip={trip} budgetPercentage={budgetPercentage} />
      ) : activeTab === 'expenses' ? (
        <TripExpenses trip={trip} onAddExpense={handleAddExpense} />
      ) : (
        <div>
          <div className="mb-6">
            <h2 className="text-2xl font-semibold text-zinc-900 mb-2">AI Agent Activity</h2>
            <p className="text-zinc-600">
              See what the AI agent has been doing to optimize your trip
            </p>
          </div>
          <ActivityStream actions={tripAIActions} />
        </div>
      )}
    </div>
  );
}

function ItineraryTab({ trip, budgetPercentage }: { trip: any; budgetPercentage: number }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Main Content */}
      <div className="lg:col-span-2 space-y-6">
        {/* Overview Cards */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-xl border border-zinc-200">
            <div className="flex items-center gap-2 text-zinc-600 mb-2">
              <Calendar className="w-4 h-4" />
              <span className="text-sm">Duration</span>
            </div>
            <p className="font-semibold text-zinc-900">
              {Math.ceil(
                (new Date(trip.endDate).getTime() - new Date(trip.startDate).getTime()) /
                  (1000 * 60 * 60 * 24)
              )}{' '}
              days
            </p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-zinc-200 col-span-2">
            <div className="flex items-center gap-2 text-zinc-600 mb-3">
              <Users className="w-4 h-4" />
              <span className="text-sm">Travelers ({trip.travelers.length})</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {trip.travelers.map((traveler) => (
                <div
                  key={traveler.id}
                  className="flex items-center gap-2 bg-zinc-50 px-3 py-1.5 rounded-lg border border-zinc-200"
                >
                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-medium">
                    {traveler.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="text-xs">
                    <p className="font-medium text-zinc-900">{traveler.name}</p>
                    <p className="text-zinc-500">{traveler.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Flights Section */}
        <div className="bg-white rounded-xl border border-zinc-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Plane className="w-5 h-5 text-blue-600" />
              <h2 className="text-xl font-semibold text-zinc-900">Flights</h2>
            </div>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
              Modify
            </button>
          </div>

          <div className="space-y-4">
            {trip.flights.map((flight) => {
              const flightTravelers = trip.travelers.filter((t) =>
                flight.travelers.includes(t.id)
              );

              return (
                <div key={flight.id} className="border border-zinc-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="font-semibold text-zinc-900">
                        {flight.airline} {flight.flightNumber}
                      </p>
                      <p className="text-sm text-zinc-600">{flight.class}</p>
                    </div>
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                      {flight.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-3">
                    <div>
                      <p className="text-xs text-zinc-500 mb-1">From</p>
                      <p className="font-medium text-zinc-900">{flight.from}</p>
                      <p className="text-sm text-zinc-600">
                        {new Date(flight.departure).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>

                    <div className="text-center">
                      <p className="text-xs text-zinc-500 mb-1">Duration</p>
                      <div className="flex items-center justify-center gap-2">
                        <div className="h-px bg-zinc-300 flex-1" />
                        <Clock className="w-4 h-4 text-zinc-400" />
                        <div className="h-px bg-zinc-300 flex-1" />
                      </div>
                      <p className="text-sm text-zinc-600 mt-1">{flight.duration}</p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs text-zinc-500 mb-1">To</p>
                      <p className="font-medium text-zinc-900">{flight.to}</p>
                      <p className="text-sm text-zinc-600">
                        {new Date(flight.arrival).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-zinc-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-zinc-600">Passengers:</p>
                      <div className="flex -space-x-1">
                        {flightTravelers.map((traveler) => (
                          <div
                            key={traveler.id}
                            className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-medium border-2 border-white"
                            title={traveler.name}
                          >
                            {traveler.name.split(' ').map(n => n[0]).join('')}
                          </div>
                        ))}
                      </div>
                      <p className="text-xs text-zinc-500">
                        {flightTravelers.map(t => t.name).join(', ')}
                      </p>
                    </div>
                    <p className="text-sm text-zinc-600">
                      Price: <span className="font-medium text-zinc-900">${flight.price}</span>
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Hotels Section */}
        <div className="bg-white rounded-xl border border-zinc-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Hotel className="w-5 h-5 text-purple-600" />
              <h2 className="text-xl font-semibold text-zinc-900">Accommodation</h2>
            </div>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
              Modify
            </button>
          </div>

          <div className="space-y-4">
            {trip.hotels.map((hotel) => {
              const hotelGuests = trip.travelers.filter((t) =>
                hotel.travelers.includes(t.id)
              );

              return (
                <div key={hotel.id} className="border border-zinc-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="font-semibold text-zinc-900">{hotel.name}</p>
                      <p className="text-sm text-zinc-600">{hotel.address}</p>
                    </div>
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                      {hotel.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-3">
                    <div>
                      <p className="text-xs text-zinc-500 mb-1">Check-in</p>
                      <p className="font-medium text-zinc-900">
                        {new Date(hotel.checkIn).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>

                    <div>
                      <p className="text-xs text-zinc-500 mb-1">Check-out</p>
                      <p className="font-medium text-zinc-900">
                        {new Date(hotel.checkOut).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>

                    <div>
                      <p className="text-xs text-zinc-500 mb-1">Room Type</p>
                      <p className="font-medium text-zinc-900">{hotel.roomType}</p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-zinc-200 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-zinc-600">Guests:</p>
                      <div className="flex -space-x-1">
                        {hotelGuests.map((traveler) => (
                          <div
                            key={traveler.id}
                            className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-medium border-2 border-white"
                            title={traveler.name}
                          >
                            {traveler.name.split(' ').map(n => n[0]).join('')}
                          </div>
                        ))}
                      </div>
                      <p className="text-xs text-zinc-500">
                        {hotelGuests.map(t => t.name).join(', ')}
                      </p>
                    </div>
                    <p className="text-sm text-zinc-600">
                      {hotel.nights} nights • <span className="font-medium text-zinc-900">${hotel.price}</span>
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Sidebar */}
      <div className="space-y-6">
        {/* Budget Card */}
        <div className="bg-white rounded-xl border border-zinc-200 p-6">
          <h3 className="font-semibold text-zinc-900 mb-4">Budget Overview</h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-zinc-600">Total Budget</span>
                <span className="font-medium text-zinc-900">
                  ${trip.budget.total.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-zinc-600">Spent</span>
                <span className="font-medium text-zinc-900">
                  ${trip.budget.spent.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-sm mb-3">
                <span className="text-zinc-600">Remaining</span>
                <span className="font-medium text-green-600">
                  ${(trip.budget.total - trip.budget.spent).toLocaleString()}
                </span>
              </div>

              <div className="w-full bg-zinc-200 rounded-full h-3 overflow-hidden">
                <div
                  className={`h-full transition-all ${
                    budgetPercentage > 90 ? 'bg-orange-500' : 'bg-blue-600'
                  }`}
                  style={{ width: `${budgetPercentage}%` }}
                />
              </div>
              <p className="text-xs text-zinc-500 mt-2">
                {budgetPercentage.toFixed(1)}% of budget used
              </p>
            </div>

            <div className="pt-4 border-t border-zinc-200 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-zinc-600">Flights</span>
                <span className="font-medium text-zinc-900">
                  ${trip.flights.reduce((sum, f) => sum + f.price, 0).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-600">Hotels</span>
                <span className="font-medium text-zinc-900">
                  ${trip.hotels.reduce((sum, h) => sum + h.price, 0).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl p-6 text-white">
          <h3 className="font-semibold mb-3">Need Help?</h3>
          <p className="text-sm text-blue-100 mb-4">
            Ask our AI assistant to modify bookings, get recommendations, or answer questions.
          </p>
          <button className="w-full bg-white text-blue-600 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
            Chat with AI
          </button>
        </div>
      </div>
    </div>
  );
}