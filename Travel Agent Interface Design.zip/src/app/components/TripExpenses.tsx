import { useState } from 'react';
import { Upload, Receipt, Filter, Plus, X, Check, AlertCircle } from 'lucide-react';
import { Trip, Expense } from '../data/mockData';

interface TripExpensesProps {
  trip: Trip;
  onAddExpense?: (expense: Expense) => void;
}

export function TripExpenses({ trip, onAddExpense }: TripExpensesProps) {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterTraveler, setFilterTraveler] = useState<string>('all');
  const [showUploadModal, setShowUploadModal] = useState(false);

  const filteredExpenses = trip.expenses.filter((expense) => {
    const categoryMatch = filterCategory === 'all' || expense.category === filterCategory;
    const travelerMatch = filterTraveler === 'all' || expense.travelerId === filterTraveler;
    return categoryMatch && travelerMatch;
  });

  const totalExpenses = filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const pendingExpenses = filteredExpenses.filter((e) => e.status === 'pending').length;

  const categoryColors: Record<string, string> = {
    flight: 'bg-blue-100 text-blue-700',
    hotel: 'bg-purple-100 text-purple-700',
    meals: 'bg-orange-100 text-orange-700',
    transportation: 'bg-green-100 text-green-700',
    entertainment: 'bg-pink-100 text-pink-700',
    other: 'bg-zinc-100 text-zinc-700',
  };

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-zinc-200">
          <p className="text-sm text-zinc-600 mb-1">Total Expenses</p>
          <p className="text-2xl font-semibold text-zinc-900">${totalExpenses.toFixed(2)}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-zinc-200">
          <p className="text-sm text-zinc-600 mb-1">Pending Approval</p>
          <p className="text-2xl font-semibold text-orange-600">{pendingExpenses}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-zinc-200">
          <p className="text-sm text-zinc-600 mb-1">Total Receipts</p>
          <p className="text-2xl font-semibold text-zinc-900">{filteredExpenses.length}</p>
        </div>
      </div>

      {/* Filters and Actions */}
      <div className="bg-white rounded-xl border border-zinc-200 p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Filter className="w-4 h-4 text-zinc-600" />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="px-3 py-2 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Categories</option>
              <option value="meals">Meals</option>
              <option value="transportation">Transportation</option>
              <option value="hotel">Hotel</option>
              <option value="flight">Flight</option>
              <option value="entertainment">Entertainment</option>
              <option value="other">Other</option>
            </select>

            <select
              value={filterTraveler}
              onChange={(e) => setFilterTraveler(e.target.value)}
              className="px-3 py-2 border border-zinc-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Travelers</option>
              {trip.travelers.map((traveler) => (
                <option key={traveler.id} value={traveler.id}>
                  {traveler.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Expense
          </button>
        </div>
      </div>

      {/* Expenses List */}
      <div className="space-y-3">
        {filteredExpenses.length === 0 ? (
          <div className="bg-white rounded-xl border border-zinc-200 p-12 text-center">
            <Receipt className="w-12 h-12 text-zinc-300 mx-auto mb-4" />
            <p className="text-zinc-600 mb-2">No expenses found</p>
            <p className="text-sm text-zinc-500">
              Upload receipts or use the AI assistant to add expenses
            </p>
          </div>
        ) : (
          filteredExpenses.map((expense) => {
            const traveler = trip.travelers.find((t) => t.id === expense.travelerId);
            const linkedBooking =
              expense.linkedBookingType === 'flight'
                ? trip.flights.find((f) => f.id === expense.linkedBookingId)
                : expense.linkedBookingType === 'hotel'
                ? trip.hotels.find((h) => h.id === expense.linkedBookingId)
                : null;

            return (
              <div
                key={expense.id}
                className="bg-white rounded-xl border border-zinc-200 p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    {/* Receipt Icon/Image */}
                    <div className="w-12 h-12 bg-zinc-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Receipt className="w-6 h-6 text-zinc-400" />
                    </div>

                    {/* Expense Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-zinc-900">{expense.vendor}</h4>
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            categoryColors[expense.category]
                          }`}
                        >
                          {expense.category}
                        </span>
                      </div>

                      <p className="text-sm text-zinc-600 mb-2">{expense.description}</p>

                      <div className="flex items-center gap-4 text-sm text-zinc-500">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-medium">
                            {traveler?.name.split(' ').map(n => n[0]).join('') || '?'}
                          </div>
                          <span>{traveler?.name}</span>
                        </div>

                        <span>•</span>

                        <span>
                          {new Date(expense.date).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </span>

                        {linkedBooking && (
                          <>
                            <span>•</span>
                            <span className="text-blue-600">
                              Linked to {expense.linkedBookingType}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Amount and Status */}
                    <div className="text-right flex-shrink-0">
                      <p className="text-xl font-semibold text-zinc-900 mb-1">
                        ${expense.amount.toFixed(2)}
                      </p>
                      <div
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                          expense.status === 'approved'
                            ? 'bg-green-100 text-green-700'
                            : expense.status === 'rejected'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-orange-100 text-orange-700'
                        }`}
                      >
                        {expense.status === 'approved' && <Check className="w-3 h-3" />}
                        {expense.status === 'pending' && <AlertCircle className="w-3 h-3" />}
                        {expense.status === 'rejected' && <X className="w-3 h-3" />}
                        {expense.status.charAt(0).toUpperCase() + expense.status.slice(1)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <ExpenseUploadModal
          trip={trip}
          onClose={() => setShowUploadModal(false)}
          onSubmit={(expense) => {
            onAddExpense?.(expense);
            setShowUploadModal(false);
          }}
        />
      )}
    </div>
  );
}

interface ExpenseUploadModalProps {
  trip: Trip;
  onClose: () => void;
  onSubmit: (expense: Expense) => void;
}

function ExpenseUploadModal({ trip, onClose, onSubmit }: ExpenseUploadModalProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    travelerId: trip.travelers[0]?.id || '',
    amount: '',
    category: 'meals' as Expense['category'],
    vendor: '',
    date: new Date().toISOString().split('T')[0],
    description: '',
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    setUploadedFile(file);
    setIsProcessing(true);

    // Simulate AI processing of receipt
    setTimeout(() => {
      setFormData({
        ...formData,
        vendor: 'Auto-detected Restaurant',
        amount: '45.50',
        description: 'Business meal',
      });
      setIsProcessing(false);
    }, 1500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newExpense: Expense = {
      id: `e${Date.now()}`,
      travelerId: formData.travelerId,
      amount: parseFloat(formData.amount),
      currency: 'USD',
      category: formData.category,
      vendor: formData.vendor,
      date: formData.date,
      description: formData.description,
      receiptUrl: uploadedFile ? URL.createObjectURL(uploadedFile) : undefined,
      status: 'pending',
    };

    onSubmit(newExpense);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-zinc-200 p-6 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-zinc-900">Add Expense</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-zinc-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Upload Area */}
          <div>
            <label className="block text-sm font-medium text-zinc-900 mb-2">
              Receipt Image
            </label>
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
                dragActive
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-zinc-300 hover:border-zinc-400'
              }`}
            >
              {uploadedFile ? (
                <div className="flex items-center justify-center gap-3">
                  <Receipt className="w-8 h-8 text-green-600" />
                  <div className="text-left">
                    <p className="font-medium text-zinc-900">{uploadedFile.name}</p>
                    <p className="text-sm text-zinc-500">
                      {(uploadedFile.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                  {isProcessing && (
                    <div className="ml-4 text-sm text-blue-600">Processing with AI...</div>
                  )}
                </div>
              ) : (
                <>
                  <Upload className="w-12 h-12 text-zinc-400 mx-auto mb-4" />
                  <p className="text-zinc-600 mb-2">
                    Drag and drop your receipt here, or click to browse
                  </p>
                  <p className="text-sm text-zinc-500">
                    AI will automatically extract details from your receipt
                  </p>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileInput}
                    className="hidden"
                    id="file-upload"
                  />
                  <label
                    htmlFor="file-upload"
                    className="inline-block mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    Choose File
                  </label>
                </>
              )}
            </div>
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-zinc-900 mb-2">Traveler</label>
              <select
                value={formData.travelerId}
                onChange={(e) => setFormData({ ...formData, travelerId: e.target.value })}
                className="w-full px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                {trip.travelers.map((traveler) => (
                  <option key={traveler.id} value={traveler.id}>
                    {traveler.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-900 mb-2">Category</label>
              <select
                value={formData.category}
                onChange={(e) =>
                  setFormData({ ...formData, category: e.target.value as Expense['category'] })
                }
                className="w-full px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="meals">Meals</option>
                <option value="transportation">Transportation</option>
                <option value="hotel">Hotel</option>
                <option value="flight">Flight</option>
                <option value="entertainment">Entertainment</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-zinc-900 mb-2">Amount (USD)</label>
              <input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="0.00"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-900 mb-2">Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-900 mb-2">Vendor</label>
            <input
              type="text"
              value={formData.vendor}
              onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
              className="w-full px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Restaurant name, store, etc."
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-900 mb-2">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="What was this expense for?"
              rows={3}
              required
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 justify-end pt-4 border-t border-zinc-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-zinc-300 text-zinc-700 rounded-lg hover:bg-zinc-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Submit Expense
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
