import { useState, useEffect } from 'react';
import { Sparkles, X, ChevronDown, ChevronUp } from 'lucide-react';
import { AIAction } from '../data/mockData';

interface AIAgentStatusProps {
  currentAction?: AIAction;
}

export function AIAgentStatus({ currentAction }: AIAgentStatusProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  // Auto-expand when new action starts
  useEffect(() => {
    if (currentAction && currentAction.type !== 'completed') {
      setIsExpanded(true);
      setIsDismissed(false);
    }
  }, [currentAction?.id]);

  if (isDismissed || !currentAction) return null;

  const isActive = currentAction.type !== 'completed';

  return (
    <div
      className={`border-b transition-all ${
        isActive
          ? 'bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200'
          : 'bg-green-50 border-green-200'
      }`}
    >
      <div className="px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1">
            <div
              className={`p-2 rounded-lg ${
                isActive ? 'bg-blue-100' : 'bg-green-100'
              }`}
            >
              <Sparkles
                className={`w-4 h-4 ${
                  isActive ? 'text-blue-600 animate-pulse' : 'text-green-600'
                }`}
              />
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p
                  className={`text-sm font-medium ${
                    isActive ? 'text-blue-900' : 'text-green-900'
                  }`}
                >
                  {isActive ? 'AI Agent is working...' : 'AI Agent completed task'}
                </p>
                <span
                  className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                    isActive
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-green-100 text-green-700'
                  }`}
                >
                  {currentAction.action}
                </span>
              </div>

              {isActive && currentAction.progress !== undefined && (
                <div className="mt-2 flex items-center gap-3">
                  <div className="flex-1 h-1.5 bg-white rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 transition-all duration-300"
                      style={{ width: `${currentAction.progress}%` }}
                    />
                  </div>
                  <span className="text-xs text-blue-700 font-medium">
                    {currentAction.progress}%
                  </span>
                </div>
              )}

              {isExpanded && (
                <p className="text-sm text-zinc-600 mt-1">
                  {currentAction.description}
                </p>
              )}
            </div>

            {currentAction.metadata && (
              <div className="text-right text-sm text-zinc-600">
                {currentAction.metadata.itemsProcessed !== undefined && (
                  <span>
                    {currentAction.metadata.itemsProcessed}/{currentAction.metadata.totalItems}
                  </span>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 ml-4">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 hover:bg-white/50 rounded transition-colors"
            >
              {isExpanded ? (
                <ChevronUp className="w-4 h-4 text-zinc-600" />
              ) : (
                <ChevronDown className="w-4 h-4 text-zinc-600" />
              )}
            </button>
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1 hover:bg-white/50 rounded transition-colors"
            >
              <X className="w-4 h-4 text-zinc-600" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
