import { Link } from 'react-router';
import { Calendar, MapPin, Users } from 'lucide-react';
import { mockTrips } from '../data/mockData';
import { useState } from 'react';

export function AllTrips() {
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'past'>('all');

  const filteredTrips =
    filter === 'all' ? mockTrips : mockTrips.filter((trip) => trip.status === filter);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 mb-2">All Trips</h1>
        <p className="text-zinc-600">Manage and view all your business travel</p>
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filter === 'all'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-zinc-700 border border-zinc-200 hover:bg-zinc-50'
          }`}
        >
          All Trips
        </button>
        <button
          onClick={() => setFilter('upcoming')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filter === 'upcoming'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-zinc-700 border border-zinc-200 hover:bg-zinc-50'
          }`}
        >
          Upcoming
        </button>
        <button
          onClick={() => setFilter('past')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filter === 'past'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-zinc-700 border border-zinc-200 hover:bg-zinc-50'
          }`}
        >
          Past
        </button>
      </div>

      {/* Trips List */}
      <div className="space-y-4">
        {filteredTrips.map((trip) => {
          return (
            <Link
              key={trip.id}
              to={`/trip/${trip.id}`}
              className="bg-white rounded-xl border border-zinc-200 overflow-hidden hover:shadow-lg transition-all flex"
            >
              <div className="w-64 h-48 flex-shrink-0">
                <img
                  src={trip.imageUrl}
                  alt={trip.destination}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-zinc-900 mb-1">{trip.title}</h3>
                    <div className="flex items-center gap-2 text-zinc-600">
                      <MapPin className="w-4 h-4" />
                      <span>{trip.destination}</span>
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      trip.status === 'upcoming'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-zinc-100 text-zinc-700'
                    }`}
                  >
                    {trip.status === 'upcoming' ? 'Upcoming' : 'Completed'}
                  </span>
                </div>

                <div className="flex items-center gap-6 text-sm text-zinc-600">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <div>
                      <p className="font-medium text-zinc-900">
                        {new Date(trip.startDate).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                        })}{' '}
                        -{' '}
                        {new Date(trip.endDate).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Users className="w-4 h-4" />
                    <div className="flex -space-x-2">
                      {trip.travelers.slice(0, 3).map((traveler) => (
                        <div
                          key={traveler.id}
                          className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-medium border-2 border-white"
                          title={`${traveler.name} - ${traveler.role}`}
                        >
                          {traveler.name.split(' ').map(n => n[0]).join('')}
                        </div>
                      ))}
                      {trip.travelers.length > 3 && (
                        <div className="w-7 h-7 rounded-full bg-zinc-200 flex items-center justify-center text-zinc-600 text-xs font-medium border-2 border-white">
                          +{trip.travelers.length - 3}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}