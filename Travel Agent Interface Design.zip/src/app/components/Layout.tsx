import { Outlet, Link, useLocation } from 'react-router';
import { LayoutDashboard, Plane, Settings, Menu, X, MessageSquare } from 'lucide-react';
import { useState } from 'react';
import { AIChat } from './AIChat';
import { AIAgentStatus } from './AIAgentStatus';
import { mockAIActions } from '../data/mockData';

export function Layout() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);

  // In a real app, this would come from a global state/context
  // For now, we'll simulate an active action
  const activeAction = mockAIActions.find(a => a.type !== 'completed');

  const navItems = [
    { path: '/', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/trips', label: 'All Trips', icon: Plane },
    { path: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-zinc-50">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-0'
        } bg-zinc-900 text-white transition-all duration-300 overflow-hidden flex flex-col`}
      >
        <div className="p-6 border-b border-zinc-800">
          <h1 className="text-xl font-semibold">TravelAI Enterprise</h1>
          <p className="text-sm text-zinc-400 mt-1">Intelligent Travel Management</p>
        </div>

        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive
                        ? 'bg-blue-600 text-white'
                        : 'text-zinc-300 hover:bg-zinc-800'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-4 border-t border-zinc-800">
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className="flex items-center gap-3 px-4 py-3 rounded-lg w-full bg-blue-600 hover:bg-blue-700 transition-colors"
          >
            <MessageSquare className="w-5 h-5" />
            <span>AI Assistant</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-zinc-200">
          <div className="px-6 py-4 flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-zinc-100 rounded-lg transition-colors"
            >
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium">Sarah Chen</p>
                <p className="text-xs text-zinc-500">Travel Manager</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white">
                SC
              </div>
            </div>
          </div>

          {/* AI Agent Status Bar */}
          <AIAgentStatus currentAction={activeAction} />
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>

      {/* AI Chat Sidebar */}
      <AIChat isOpen={chatOpen} onClose={() => setChatOpen(false)} />
    </div>
  );
}