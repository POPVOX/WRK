import { useState, useRef, useEffect } from 'react';
import { X, Send, Sparkles } from 'lucide-react';
import { ChatMessage, initialChatMessages } from '../data/mockData';

interface AIChatProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AIChat({ isOpen, onClose }: AIChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialChatMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response with detailed status
    setTimeout(() => {
      const aiResponse = generateAIResponse(input);
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();

    if (input.includes('expense') || input.includes('receipt')) {
      return 'I can help you add expenses! You can upload a receipt and I\'ll automatically extract the amount, vendor, date, and category using AI. Would you like to add an expense now? Just describe it or tell me about the receipt you have.';
    }
    if (input.includes('add') && (input.includes('dinner') || input.includes('lunch') || input.includes('meal'))) {
      return 'Great! I can add that meal expense for you. Could you tell me: 1) The amount spent, 2) The restaurant name, and 3) Which trip this was for? Or you can upload the receipt in the Expenses tab and I\'ll extract all the details automatically.';
    }
    if (input.includes('change') && input.includes('flight')) {
      return 'I can help you change your flight. Which trip would you like to modify? I see you have upcoming trips to Tokyo and London. Please let me know which one, and what changes you\'d like to make (date, time, class, etc.).';
    }
    if (input.includes('hotel') || input.includes('accommodation')) {
      return 'I\'d be happy to help with hotel arrangements. Are you looking to modify an existing hotel booking, or would you like recommendations for a new trip? I can also help you upgrade rooms or add amenities to current reservations.';
    }
    if (input.includes('budget') || input.includes('cost')) {
      return 'Your Tokyo Business Summit trip has a budget of $12,500 with $9,200 already spent. The London Tech Conference has $18,000 budgeted with $14,500 spent. Would you like a detailed breakdown of any specific trip expenses?';
    }
    if (input.includes('weather') || input.includes('climate')) {
      return 'I can provide weather forecasts for your destinations. Tokyo in mid-March typically has temperatures around 12-15°C (54-59°F) with occasional rain. London in April averages 8-14°C (46-57°F). Would you like detailed forecasts closer to your departure date?';
    }
    if (input.includes('recommend') || input.includes('suggest')) {
      return 'Based on your travel history and preferences, I can suggest restaurants, activities, and local experiences. For Tokyo, I recommend visiting the teamLab Borderless museum and dining at Sukiyabashi Jiro. In London, the Churchill War Rooms and dinner at Dishoom are excellent choices. Would you like more specific recommendations?';
    }
    if (input.includes('cancel') || input.includes('refund')) {
      return 'I understand you\'re asking about cancellations. Please note that cancellation policies vary by booking. Your Business class flights typically have flexible change policies. Which booking would you like to review for cancellation or refund options?';
    }
    if (input.includes('visa') || input.includes('document')) {
      return 'For Japan, US citizens can stay up to 90 days visa-free for tourism or business. The UK allows visa-free entry for up to 6 months. Make sure your passport is valid for at least 6 months beyond your travel dates. Would you like me to help with any other travel documents?';
    }

    return 'I\'m here to help with your travel needs. I can assist with changing flights, modifying hotel bookings, adding expenses and receipts, providing destination information, managing budgets, and answering any questions about your upcoming trips to Tokyo and London. What would you like to know?';
  };

  if (!isOpen) return null;

  return (
    <div className="w-96 bg-white border-l border-zinc-200 flex flex-col h-screen">
      {/* Chat Header */}
      <div className="p-4 border-b border-zinc-200 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white">
            <Sparkles className="w-5 h-5" />
            <div>
              <h3 className="font-semibold">AI Travel Assistant</h3>
              <p className="text-xs text-blue-100">Always here to help</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white/20 rounded-lg transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg px-4 py-2 ${
                message.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-zinc-100 text-zinc-900'
              }`}
            >
              <p className="text-sm">{message.content}</p>
              <p
                className={`text-xs mt-1 ${
                  message.role === 'user' ? 'text-blue-100' : 'text-zinc-500'
                }`}
              >
                {message.timestamp.toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-zinc-100 text-zinc-900 rounded-lg px-4 py-2">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                <span className="w-2 h-2 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                <span className="w-2 h-2 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-zinc-200">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask me anything about your trips..."
            className="flex-1 px-4 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          <button
            onClick={() => setInput('Can I change my Tokyo flight to a day later?')}
            className="text-xs px-3 py-1 bg-zinc-100 hover:bg-zinc-200 rounded-full transition-colors"
          >
            Change flight
          </button>
          <button
            onClick={() => setInput('What\'s the weather like in Tokyo in March?')}
            className="text-xs px-3 py-1 bg-zinc-100 hover:bg-zinc-200 rounded-full transition-colors"
          >
            Weather info
          </button>
          <button
            onClick={() => setInput('Show me my trip budget breakdown')}
            className="text-xs px-3 py-1 bg-zinc-100 hover:bg-zinc-200 rounded-full transition-colors"
          >
            Budget details
          </button>
        </div>
      </div>
    </div>
  );
}