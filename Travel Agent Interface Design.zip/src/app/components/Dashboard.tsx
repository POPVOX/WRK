import { Link } from 'react-router';
import { Calendar, Plane, MapPin, Sparkles } from 'lucide-react';
import { mockTrips, mockAIActions } from '../data/mockData';
import { ActivityStream } from './ActivityStream';

export function Dashboard() {
  const upcomingTrips = mockTrips.filter((trip) => trip.status === 'upcoming');
  const recentAIActions = mockAIActions.slice(0, 5);

  return (
    <div className="p-8">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 mb-2">Welcome back, Sarah</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Upcoming Trips */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-semibold text-zinc-900">Upcoming Trips</h2>
              <Link
                to="/trips"
                className="text-blue-600 hover:text-blue-700 transition-colors text-sm font-medium"
              >
                View all trips →
              </Link>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {upcomingTrips.map((trip) => {
                const daysUntil = Math.ceil(
                  (new Date(trip.startDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
                );

                return (
                  <Link
                    key={trip.id}
                    to={`/trip/${trip.id}`}
                    className="bg-white rounded-xl border border-zinc-200 overflow-hidden hover:shadow-xl transition-all group"
                  >
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={trip.imageUrl}
                        alt={trip.destination}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      <div className="absolute bottom-4 left-4 text-white">
                        <h3 className="text-xl font-semibold mb-1">{trip.title}</h3>
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="w-4 h-4" />
                          <span>{trip.destination}</span>
                        </div>
                      </div>
                      {daysUntil <= 30 && (
                        <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                          {daysUntil} days
                        </div>
                      )}
                    </div>

                    <div className="p-6">
                      <div className="flex items-center gap-4 text-sm text-zinc-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {new Date(trip.startDate).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                            })}{' '}
                            -{' '}
                            {new Date(trip.endDate).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                            })}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Plane className="w-4 h-4" />
                          <span>{trip.travelers.length} travelers</span>
                        </div>
                      </div>
                      
                      <div className="mt-4 flex -space-x-2">
                        {trip.travelers.slice(0, 4).map((traveler) => (
                          <div
                            key={traveler.id}
                            className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-medium border-2 border-white"
                            title={`${traveler.name} - ${traveler.role}`}
                          >
                            {traveler.name.split(' ').map(n => n[0]).join('')}
                          </div>
                        ))}
                        {trip.travelers.length > 4 && (
                          <div className="w-8 h-8 rounded-full bg-zinc-200 flex items-center justify-center text-zinc-600 text-xs font-medium border-2 border-white">
                            +{trip.travelers.length - 4}
                          </div>
                        )}
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white">
            <h2 className="text-2xl font-semibold mb-4">Need help planning your next trip?</h2>
            <p className="mb-6 text-blue-100">
              Our AI assistant can help you book flights, find hotels, and manage your itinerary - all
              through natural conversation.
            </p>
            <div className="flex gap-4">
              <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                Start Planning
              </button>
              <button className="border border-white text-white px-6 py-3 rounded-lg font-medium hover:bg-white/10 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>

        {/* Sidebar - AI Activity */}
        <div>
          <div className="flex items-center gap-2 mb-6">
            <Sparkles className="w-5 h-5 text-blue-600" />
            <h2 className="text-xl font-semibold text-zinc-900">AI Activity</h2>
          </div>
          <ActivityStream actions={recentAIActions} limit={5} />
        </div>
      </div>
    </div>
  );
}