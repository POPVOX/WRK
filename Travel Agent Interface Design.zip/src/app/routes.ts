import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./components/Dashboard";
import { TripDetails } from "./components/TripDetails";
import { AllTrips } from "./components/AllTrips";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "trips", Component: AllTrips },
      { path: "trip/:tripId", Component: TripDetails },
    ],
  },
]);
